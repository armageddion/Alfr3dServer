#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_ouimeaux
----------------------------------

Tests for `ouimeaux` module.
"""

import unittest


import ouimeaux

class TestOuimeaux(unittest.TestCase):

    def setUp(self):
        pass

    def test_something(self):
        pass

    def tearDown(self):
        pass

if __name__ == '__main__':
    unittest.main()