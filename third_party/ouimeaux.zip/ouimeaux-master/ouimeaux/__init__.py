#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'Ian McCracken'
__email__ = 'ian.mccracken@gmail.com'
__version__ = '0.7.2'
