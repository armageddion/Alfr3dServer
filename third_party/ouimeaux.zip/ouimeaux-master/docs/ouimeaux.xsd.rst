ouimeaux.xsd package
====================

Submodules
----------

ouimeaux.xsd.device module
--------------------------

.. automodule:: ouimeaux.xsd.device
    :members:
    :undoc-members:
    :show-inheritance:

ouimeaux.xsd.service module
---------------------------

.. automodule:: ouimeaux.xsd.service
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: ouimeaux.xsd
    :members:
    :undoc-members:
    :show-inheritance:
