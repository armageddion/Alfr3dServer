ouimeaux.device.api package
===========================

Subpackages
-----------

.. toctree::

    ouimeaux.device.api.xsd

Submodules
----------

ouimeaux.device.api.service module
----------------------------------

.. automodule:: ouimeaux.device.api.service
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: ouimeaux.device.api
    :members:
    :undoc-members:
    :show-inheritance:
