ouimeaux.device.api.xsd package
===============================

Submodules
----------

ouimeaux.device.api.xsd.device module
-------------------------------------

.. automodule:: ouimeaux.device.api.xsd.device
    :members:
    :undoc-members:
    :show-inheritance:

ouimeaux.device.api.xsd.service module
--------------------------------------

.. automodule:: ouimeaux.device.api.xsd.service
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: ouimeaux.device.api.xsd
    :members:
    :undoc-members:
    :show-inheritance:
