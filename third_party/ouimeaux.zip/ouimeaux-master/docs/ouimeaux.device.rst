ouimeaux.device package
=======================

Subpackages
-----------

.. toctree::

    ouimeaux.device.api

Submodules
----------

ouimeaux.device.insight module
------------------------------

.. automodule:: ouimeaux.device.insight
    :members:
    :undoc-members:
    :show-inheritance:

ouimeaux.device.lightswitch module
----------------------------------

.. automodule:: ouimeaux.device.lightswitch
    :members:
    :undoc-members:
    :show-inheritance:

ouimeaux.device.motion module
-----------------------------

.. automodule:: ouimeaux.device.motion
    :members:
    :undoc-members:
    :show-inheritance:

ouimeaux.device.switch module
-----------------------------

.. automodule:: ouimeaux.device.switch
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: ouimeaux.device
    :members:
    :undoc-members:
    :show-inheritance:
